﻿using System;

namespace PRO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Input = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Clear = new System.Windows.Forms.Button();
            this.ShowOutput = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Output = new System.Windows.Forms.TextBox();
            this.DoMorzeovky = new System.Windows.Forms.Button();
            this.Prelozit = new System.Windows.Forms.Button();
            this.Analyzovat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(53, 13);
            this.Input.Multiline = true;
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(164, 20);
            this.Input.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Input:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Actions:";
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(224, 11);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(271, 23);
            this.Clear.TabIndex = 6;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // ShowOutput
            // 
            this.ShowOutput.Location = new System.Drawing.Point(500, 10);
            this.ShowOutput.Name = "ShowOutput";
            this.ShowOutput.Size = new System.Drawing.Size(271, 23);
            this.ShowOutput.TabIndex = 12;
            this.ShowOutput.Text = "Show Output";
            this.ShowOutput.UseVisualStyleBackColor = true;
            this.ShowOutput.Click += new System.EventHandler(this.ShowOutput_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Output:";
            // 
            // Output
            // 
            this.Output.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Output.Location = new System.Drawing.Point(13, 110);
            this.Output.Multiline = true;
            this.Output.Name = "Output";
            this.Output.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Output.Size = new System.Drawing.Size(758, 438);
            this.Output.TabIndex = 5;
            this.Output.WordWrap = false;
            // 
            // DoMorzeovky
            // 
            this.DoMorzeovky.Location = new System.Drawing.Point(64, 39);
            this.DoMorzeovky.Name = "DoMorzeovky";
            this.DoMorzeovky.Size = new System.Drawing.Size(83, 23);
            this.DoMorzeovky.TabIndex = 13;
            this.DoMorzeovky.Text = "Do morzeovky";
            this.DoMorzeovky.UseVisualStyleBackColor = true;
            this.DoMorzeovky.Click += new System.EventHandler(this.DoMorzeovky_Click);
            // 
            // Prelozit
            // 
            this.Prelozit.Location = new System.Drawing.Point(153, 39);
            this.Prelozit.Name = "Prelozit";
            this.Prelozit.Size = new System.Drawing.Size(75, 23);
            this.Prelozit.TabIndex = 14;
            this.Prelozit.Text = "Preložiť vetu";
            this.Prelozit.UseVisualStyleBackColor = true;
            this.Prelozit.Click += new System.EventHandler(this.Prelozit_Click);
            // 
            // Analyzovat
            // 
            this.Analyzovat.Location = new System.Drawing.Point(234, 39);
            this.Analyzovat.Name = "Analyzovat";
            this.Analyzovat.Size = new System.Drawing.Size(88, 23);
            this.Analyzovat.TabIndex = 15;
            this.Analyzovat.Text = "Analyzovať text";
            this.Analyzovat.UseVisualStyleBackColor = true;
            this.Analyzovat.Click += new System.EventHandler(this.Analyzovat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.Analyzovat);
            this.Controls.Add(this.Prelozit);
            this.Controls.Add(this.DoMorzeovky);
            this.Controls.Add(this.ShowOutput);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Input);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button ShowOutput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Output;
        private System.Windows.Forms.Button DoMorzeovky;
        private System.Windows.Forms.Button Prelozit;
        private System.Windows.Forms.Button Analyzovat;
    }
}

