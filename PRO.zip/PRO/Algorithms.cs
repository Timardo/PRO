﻿using System;
using System.Collections.Generic;

namespace PRO
{
    class Algorithms
    {
        static Dictionary<char, string> morseKeys = new Dictionary<char, string> {
            { 'a', ".-" },
            { 'b', "- . .." },
            { 'c', "- . -." },
            { 'd', "- . ." },
            { 'e', "." },
            { 'f', ". . -." },
            { 'g', "- - ." },
            { 'h', ". . .." },
            { 'i', ".." },
            { 'j', ". - --" },
            { 'k', "- . -" },
            { 'l', ". - .." },
            { 'm', "- -" },
            { 'n', "-." },
            { 'o', "- - -" },
            { 'p', ". - -." },
            { 'q', "- - .-" },
            { 'r', ". - ." },
            { 's', ". . ." },
            { 't', "-" },
            { 'u', ". . -" },
            { 'v', ". . .-" },
            { 'w', ". - -" },
            { 'x', "- . .-" },
            { 'y', "- . --" },
            { 'z', "- - .." }
        };

        static Dictionary<string, string> translateKeys = new Dictionary<string, string> {
            { "hello", "ahoj" },
            { "how", "ako" },
            { "i", "ja" },
            { "table", "stôl" },
            { "why", "prečo" },
            { "break", "zničiť" },
            { "bed", "posteľ" },
            { "bad", "zlý" },
            { "carpet", "koberec" },
            { "they", "oni" }
        };

        internal static string DoMorzeovky(string text)
        {
            string ret = "";

            foreach (char c in text.ToLower())
            {
                if (morseKeys.ContainsKey(c))
                    ret += morseKeys[c] + " ";
                else
                    ret += " ";
            }

            return ret;
        }

        internal static string Prelozit(string text)
        {
            string ret = "";
            string[] textList = text.ToLower().Split(new char[] { ' ' });

            for (int i = 0; i < textList.Length; i++)
            {
                string s = textList[i];

                if (translateKeys.ContainsKey(s))
                    textList[i] = translateKeys[s];
            }

            ret = string.Join(" ", textList);
            return ret;
        }

        internal static string Analyzovat(string text)
        {
            text = text.ToLower();
            string[] slovaList = text.Split(new char[] { ' ', '.', ',', ';', ':', '!', '?', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, int> dict = new Dictionary<string, int>();
            int maxOccurs = 0;
            string maxSlovo = "";
            
            foreach (string slovo in slovaList)
            {
                if (dict.ContainsKey(slovo))
                {
                    dict[slovo]++;

                    if (dict[slovo] > maxOccurs)
                    {
                        maxOccurs = dict[slovo];
                        maxSlovo = slovo;
                    }
                }

                else
                    dict.Add(slovo, 1);
            }

            string ret = "Počet slov: " + slovaList.Length + Environment.NewLine +
                "Počet unikátnych slov: " + dict.Count + Environment.NewLine +
                "Maximálny počet výskytov: " + maxSlovo + ", " + maxOccurs + "x" + Environment.NewLine +
                "Slová a ich počty: " + Environment.NewLine;

            foreach (var pair in dict)
            {
                ret += pair.Key + ": " + pair.Value + Environment.NewLine;
            }

            return ret;
        }
    }
}
